﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using LiveCharts;
using LiveCharts.Wpf;

namespace Biometria
{
    /// <summary>
    /// Logika interakcji dla klasy HistogramsWindow.xaml
    /// </summary>
    public partial class HistogramsWindow : Window
    {
        BitmapSource bitmapSource;
        
        public SeriesCollection CollectionR { get; set; } = new SeriesCollection();
        public SeriesCollection CollectionG { get; set; } = new SeriesCollection();
        public SeriesCollection CollectionB { get; set; } = new SeriesCollection();
        public SeriesCollection CollectionBrightness { get; set; } = new SeriesCollection();
        
        public int[] rHistogramValues = new int[256];
        public int[] gHistogramValues = new int[256];
        public int[] bHistogramValues = new int[256];
        public int[] brightnessHistogramValues = new int[256];

        public HistogramsWindow(BitmapSource bitmapSource)
        {
            InitializeComponent();
            this.bitmapSource = bitmapSource;
            DataContext = this;
        }
        /// <summary>
        /// Oblicza i zapisuje histogramy do zmiennych typu SeriesCollection, wywoływana przy załadowaniu okna
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void LoadHistograms(object sender, RoutedEventArgs e)
        {
            WriteableBitmap writeableBitmap = new WriteableBitmap(bitmapSource);
            int stride = (writeableBitmap.PixelWidth * writeableBitmap.Format.BitsPerPixel + 7) / 8;
            int arraySize = stride * bitmapSource.PixelHeight;
            byte[] pixels = new byte[arraySize];
            //int index = (int)p.Y * stride + 4 * (int)p.X;

            writeableBitmap.CopyPixels(pixels, stride, 0);
            // zlicza wystąpienia wartości 0-255 w kanale
            for (int x = 0; x < writeableBitmap.PixelWidth; x++)
                for (int y = 0; y < writeableBitmap.PixelHeight; y++)
                {
                    int rIndex = y * stride + 4 * x + 2;
                    int gIndex = y * stride + 4 * x + 1;
                    int bIndex = y * stride + 4 * x;
                    try
                    {
                        int r = pixels[rIndex];
                        int g = pixels[gIndex];
                        int b = pixels[bIndex];
                        int brightness = (r + g + b) / 3;
                        rHistogramValues[r]++;
                        gHistogramValues[g]++;
                        bHistogramValues[b]++;
                        brightnessHistogramValues[brightness]++;
                    }
                    catch (IndexOutOfRangeException) { }
                }
            CollectionR.Add(new LineSeries
            {
                Values = new ChartValues<int>(rHistogramValues),
                LineSmoothness = 0
            });
            CollectionG.Add(new LineSeries
            {
                Values = new ChartValues<int>(gHistogramValues),
                LineSmoothness = 0
            });
            CollectionB.Add(new LineSeries
            {
                Values = new ChartValues<int>(bHistogramValues),
                LineSmoothness = 0
            });
            CollectionBrightness.Add(new LineSeries
            {
                Values = new ChartValues<int>(brightnessHistogramValues),
                LineSmoothness = 0
            });
        }
    }
}
