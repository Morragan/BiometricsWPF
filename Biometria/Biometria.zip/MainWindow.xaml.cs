﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using Microsoft.Win32;

namespace Biometria
{
    public partial class MainWindow : Window
    {
        byte[] pixels;
        BitmapSource bitmapSource,
            savedBitmapCopy;
        Image image;
        ScaleTransform scaleTransform;

        public int[] rHistogramValues;
        public int[] gHistogramValues;
        public int[] bHistogramValues;
        public int[] brightnessHistogramValues;

        // Bindowane właściwości
        public Brush RectangleFill { get; set; }
        public double Brightness { get; set; } = 1;
        public uint StretchingValA { get; set; } = 0;
        public uint StretchingValB { get; set; } = 255;

        public MainWindow()
        {
            InitializeComponent();
            // to sprawia, że bindingi w xaml widzą właściwości z klasy MainWindow
            DataContext = this;

            RectangleFill = new SolidColorBrush(Colors.Black);
            scaleTransform = new ScaleTransform();
            Main_Canvas.RenderTransform = scaleTransform;
        }

        /// <summary>
        /// Pobiera obraz z wybranego pliku i zapisuje go do zmiennej typu BitmapSource. Wywoływana po kliknięciu "Otwórz"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OpenImage(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog
            {
                Filter = "JPG Files (*.jpg)|*.jpg|JPEG Files (*.jpeg)|*.jpeg|PNG Files (*.png)|*.png|Bitmap Files (*.bmp)|*.bmp|GIF Files (*.gif)|*.gif|TIFF Files (*.tiff)|*.tiff",
                FilterIndex = 3,
                Multiselect = false
            };

            if (ofd.ShowDialog() == false) return;
            // wyczyść canvas
            Main_Canvas.Children.Clear();
            //otwórz i odpowiednio zdekoduj obraz
            Stream imageStreamSource = new FileStream(ofd.FileName, FileMode.Open, FileAccess.Read, FileShare.Read);
            BitmapDecoder decoder;
            switch (ofd.FileName.Split('.').Last())
            {
                case "jpg":
                    decoder = new JpegBitmapDecoder(imageStreamSource, BitmapCreateOptions.PreservePixelFormat, BitmapCacheOption.Default);
                    break;
                case "jpeg":
                    decoder = new JpegBitmapDecoder(imageStreamSource, BitmapCreateOptions.PreservePixelFormat, BitmapCacheOption.Default);
                    break;
                case "png":
                    decoder = new PngBitmapDecoder(imageStreamSource, BitmapCreateOptions.PreservePixelFormat, BitmapCacheOption.Default);
                    break;
                case "bmp":
                    decoder = new BmpBitmapDecoder(imageStreamSource, BitmapCreateOptions.PreservePixelFormat, BitmapCacheOption.Default);
                    break;
                case "gif":
                    decoder = new GifBitmapDecoder(imageStreamSource, BitmapCreateOptions.PreservePixelFormat, BitmapCacheOption.Default);
                    break;
                case "tiff":
                    decoder = new TiffBitmapDecoder(imageStreamSource, BitmapCreateOptions.PreservePixelFormat, BitmapCacheOption.Default);
                    break;
                default:
                    decoder = new TiffBitmapDecoder(imageStreamSource, BitmapCreateOptions.PreservePixelFormat, BitmapCacheOption.Default);
                    break;
            }
            bitmapSource = decoder.Frames[0];
            savedBitmapCopy = decoder.Frames[0];
            // zresetuj skalę
            Zoom_Slider.Value = 1;
            //// zarezerwuj pamięć na tablicę pikseli
            //int stride = (bitmapSource.PixelWidth * bitmapSource.Format.BitsPerPixel + 7) / 8;
            //int arraySize = stride * bitmapSource.PixelHeight;
            //pixels = new byte[arraySize];
            // zapisz do wpf-owej kontrolki zdjęcia, żeby móc ją wrzucić na canvas
            image = new Image();
            // wyłącz blurring
            image.UseLayoutRounding = true;
            RenderOptions.SetBitmapScalingMode(image, BitmapScalingMode.NearestNeighbor);
            RenderOptions.SetEdgeMode(image, EdgeMode.Aliased);
            image.Stretch = Stretch.None;
            image.Source = bitmapSource;
            Main_Canvas.Children.Add(image);
            // dopasuj rozmiar canvas do wymiarów zdjęcia
            Main_Canvas.Width = bitmapSource.Width;
            Main_Canvas.Height = bitmapSource.Height;
            // ustaw focus na canvas
            Main_Canvas.Focus();

            // włącz kontrolki
            SaveAs_MenuOption.IsEnabled = true;
            Histogram_MenuOption.IsEnabled = true;
            Zoom_Slider.IsEnabled = true;
            Parameters_GroupBox.IsEnabled = true;
            Stretching_GroupBox.IsEnabled = true;
            Equalizing_GroupBox.IsEnabled = true;

            // przeładowanie bitmapy
            ChangePixel(sender, new MouseButtonEventArgs(Mouse.PrimaryDevice, Environment.TickCount, MouseButton.Left) { RoutedEvent = Button.ClickEvent });
            ChangePixel(sender, new MouseButtonEventArgs(Mouse.PrimaryDevice, Environment.TickCount, MouseButton.Left) { RoutedEvent = Button.ClickEvent });
        }

        /// <summary>
        /// Jeżeli wciśnięty jest klawisz ctrl, zmienia kolor piksela pod kursorem na wybrany. 
        /// Jeżeli nie, ustawia wybrany kolor na kolor piksela pod kursorem. Wywoływana po kliknięciu canvasu
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ChangePixel(object sender, MouseButtonEventArgs e)
        {
            Point p = e.GetPosition(image);

            var writeableBitmap = new WriteableBitmap(bitmapSource);
            int stride = (writeableBitmap.PixelWidth * writeableBitmap.Format.BitsPerPixel + 7) / 8;
            int arraySize = stride * bitmapSource.PixelHeight;
            pixels = new byte[arraySize];
            int index = (int)p.Y * stride + 4 * (int)p.X;

            writeableBitmap.CopyPixels(pixels, stride, 0);

            if (Keyboard.IsKeyDown(Key.LeftCtrl) || Keyboard.IsKeyDown(Key.RightCtrl))
            {
                pixels[index] = ((SolidColorBrush)RectangleFill).Color.B;
                pixels[index + 1] = ((SolidColorBrush)RectangleFill).Color.G;
                pixels[index + 2] = ((SolidColorBrush)RectangleFill).Color.R;
            }
            else
            {
                // ustaw kolor pędzla na kolor wybranego piksela
                try
                {
                    R_Slider.Value = pixels[index + 2];
                    G_Slider.Value = pixels[index + 1];
                    B_Slider.Value = pixels[index];
                }
                catch (IndexOutOfRangeException)
                {
                    R_Slider.Value = 255;
                    G_Slider.Value = 255;
                    B_Slider.Value = 255;
                }
            }
            // zapisz do bitmapy
            Int32Rect rect = new Int32Rect(0, 0, writeableBitmap.PixelWidth, writeableBitmap.PixelHeight);
            writeableBitmap.WritePixels(rect, pixels, stride, 0);
            image.Source = writeableBitmap;
            bitmapSource = ConvertWriteableBitmapToBitmapImage(writeableBitmap);
        }

        /// <summary>
        /// Zamienia edytowalną bitmapę na taką, której można użyć jako zdjęcia
        /// </summary>
        /// <param name="wbm"></param>
        /// <returns></returns>
        public BitmapImage ConvertWriteableBitmapToBitmapImage(WriteableBitmap wbm)
        {
            BitmapImage bmImage = new BitmapImage();
            using (MemoryStream stream = new MemoryStream())
            {
                PngBitmapEncoder encoder = new PngBitmapEncoder();
                encoder.Frames.Add(BitmapFrame.Create(wbm));
                encoder.Save(stream);
                bmImage.BeginInit();
                bmImage.CacheOption = BitmapCacheOption.OnLoad;
                bmImage.StreamSource = stream;
                bmImage.EndInit();
                bmImage.Freeze();
            }
            return bmImage;
        }

        /// <summary>
        /// Zapisuje bitmapę do pliku z wybranym formatowaniem. Wywoływana po kliknięciu "Zapisz jako"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SaveToFile(object sender, RoutedEventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "JPEG Files (*.jpg)|*.jpg|PNG Files (*.png)|*.png|Bitmap Files (*.bmp)|*.bmp|GIF Files (*.gif)|*.gif|TIFF Files (*.tiff)|*.tiff";

            if (sfd.ShowDialog() == true)
            {
                //zapis do pliku sfd.FileName
                BitmapEncoder encoder;
                switch (sfd.FileName.Split('.').Last())
                {
                    case "jpg":
                        encoder = new JpegBitmapEncoder();
                        break;
                    case "png":
                        encoder = new PngBitmapEncoder();
                        break;
                    case "bmp":
                        encoder = new BmpBitmapEncoder();
                        break;
                    case "gif":
                        encoder = new GifBitmapEncoder();
                        break;
                    case "tiff":
                        encoder = new TiffBitmapEncoder();
                        break;
                    default:
                        encoder = new TiffBitmapEncoder();
                        break;
                }

                SaveUsingEncoder(image, sfd.FileName, encoder);
            }
        }

        /// <summary>
        /// Zapisuje obraz do pliku przy użyciu wybranego kodera
        /// </summary>
        /// <param name="visual"></param>
        /// <param name="fileName"></param>
        /// <param name="encoder"></param>
        private void SaveUsingEncoder(FrameworkElement visual, string fileName, BitmapEncoder encoder)
        {
            RenderTargetBitmap bitmap = new RenderTargetBitmap((int)visual.ActualWidth, (int)visual.ActualHeight, 96, 96, PixelFormats.Pbgra32);
            bitmap.Render(visual);
            BitmapFrame frame = BitmapFrame.Create(bitmap);
            encoder.Frames.Add(frame);

            using (var stream = File.Create(fileName))
            {
                encoder.Save(stream);
            }
        }

        /// <summary>
        /// Zmienia wybrany kolor. Wywoływana o kliknięciu koloru w kontrolce color picker
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ClrPcker_Background_SelectedColorChanged(object sender, RoutedPropertyChangedEventArgs<Color?> e)
        {
            // jeżeli jeszcze nie zainicjalizowany, nic nie rób
            if (Brush_Rectangle == null) return;
            ((SolidColorBrush)RectangleFill).Color = ClrPcker_Background.SelectedColor.Value;
            R_Slider.Value = ((SolidColorBrush)RectangleFill).Color.R;
            G_Slider.Value = ((SolidColorBrush)RectangleFill).Color.G;
            B_Slider.Value = ((SolidColorBrush)RectangleFill).Color.B;
        }

        /// <summary>
        /// Rozwija kontrolkę color picker. Wywoływana po kliknięciu pola z wybranym pikselem
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OpenColorPicker(object sender, MouseButtonEventArgs e)
        {
            ClrPcker_Background.IsOpen = true;
            e.Handled = true;
        }

        /// <summary>
        /// Modyfikuje wartość barwy składowej R wybranego koloru na podstawie wartości suwaka. Wywoływana po zmianie wartości suwaka R
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SetColorFromRSlider(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            ((SolidColorBrush)RectangleFill).Color = Color.FromRgb((byte)R_Slider.Value, ((SolidColorBrush)RectangleFill).Color.G, ((SolidColorBrush)RectangleFill).Color.B);
        }

        /// <summary>
        /// Modyfikuje wartość barwy składowej G wybranego koloru na podstawie wartości suwaka. Wywoływana po zmianie wartości suwaka G
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SetColorFromGSlider(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            ((SolidColorBrush)RectangleFill).Color = Color.FromRgb(((SolidColorBrush)RectangleFill).Color.R, (byte)G_Slider.Value, ((SolidColorBrush)RectangleFill).Color.B);
        }

        /// <summary>
        /// Modyfikuje wartość barwy składowej B wybranego koloru na podstawie wartości suwaka. Wywoływana po zmianie wartości suwaka B
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SetColorFromBSlider(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            ((SolidColorBrush)RectangleFill).Color = Color.FromRgb(((SolidColorBrush)RectangleFill).Color.R, ((SolidColorBrush)RectangleFill).Color.G, (byte)B_Slider.Value);
        }

        /// <summary>
        /// Zamyka program
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CloseWindow(object sender, RoutedEventArgs e)
        {
            Close();
        }

        /// <summary>
        /// Zoomuje zdjęcie na podstawie wartości suwaka. Wywoływana po zmianie wartości suwaka zoom
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ZoomImage(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (scaleTransform == null) return;
            scaleTransform.ScaleX = scaleTransform.ScaleY = Zoom_Slider.Value;
            Main_Canvas.Height = bitmapSource.Height * Zoom_Slider.Value;
            Main_Canvas.Width = bitmapSource.Width * Zoom_Slider.Value;
        }

        private void ShowHistograms(object sender, RoutedEventArgs e)
        {
            HistogramsWindow window = new HistogramsWindow(bitmapSource);
            window.ShowDialog();
            rHistogramValues = window.rHistogramValues;
            gHistogramValues = window.gHistogramValues;
            bHistogramValues = window.bHistogramValues;
            brightnessHistogramValues = window.brightnessHistogramValues;

            HStretch_a_TextBox.Text = Array.FindIndex(brightnessHistogramValues, val => val == brightnessHistogramValues.First(i => i != 0)).ToString();
            HStretch_b_TextBox.Text = Array.LastIndexOf(brightnessHistogramValues, brightnessHistogramValues.Last(i => i != 0)).ToString();
        }

        private void ResetBrightness(object sender, RoutedEventArgs e)
        {
            bitmapSource = savedBitmapCopy;
            var writeableBitmap = new WriteableBitmap(bitmapSource);
            int stride = (writeableBitmap.PixelWidth * writeableBitmap.Format.BitsPerPixel + 7) / 8;
            writeableBitmap.CopyPixels(pixels, stride, 0);

            // zapisz do bitmapy
            Int32Rect rect = new Int32Rect(0, 0, writeableBitmap.PixelWidth, writeableBitmap.PixelHeight);
            writeableBitmap.WritePixels(rect, pixels, stride, 0);
            image.Source = writeableBitmap;
            bitmapSource = ConvertWriteableBitmapToBitmapImage(writeableBitmap);
        }

        private void ChangeBrightness(object sender, RoutedEventArgs e)
        {
            var writeableBitmap = new WriteableBitmap(bitmapSource);
            var LUT = new byte[256];
            for (int i = 0; i < 256; i++)
            {
                uint val = (uint)Math.Pow(i, Brightness);
                LUT[i] = (byte)(val > 255 ? 255 : val);
            }

            int stride = (writeableBitmap.PixelWidth * writeableBitmap.Format.BitsPerPixel + 7) / 8;
            writeableBitmap.CopyPixels(pixels, stride, 0);
            //int index = (int)p.Y * stride + 4 * (int)p.X;
            for (int x = 0; x < writeableBitmap.PixelWidth; x++) 
            {
                for (int y = 0; y < writeableBitmap.PixelHeight; y++)
                {
                    int rIndex = y * stride + 4 * x + 2;
                    int gIndex = y * stride + 4 * x + 1;
                    int bIndex = y * stride + 4 * x;
                    try
                    {
                        pixels[rIndex] = LUT[pixels[rIndex]];
                        pixels[gIndex] = LUT[pixels[gIndex]];
                        pixels[bIndex] = LUT[pixels[bIndex]];
                    }
                    catch (IndexOutOfRangeException) { }
                }
            }

            // zapisz do bitmapy
            Int32Rect rect = new Int32Rect(0, 0, writeableBitmap.PixelWidth, writeableBitmap.PixelHeight);
            writeableBitmap.WritePixels(rect, pixels, stride, 0);
            image.Source = writeableBitmap;
            bitmapSource = ConvertWriteableBitmapToBitmapImage(writeableBitmap);
        }

        private void StretchHistogram(object sender, RoutedEventArgs e)
        {
            var LUT = new byte[256];
            for (int i = 0; i < 256; i++)
            {
                int val = (int)(255 * (i - StretchingValA) / (StretchingValB - StretchingValA));
                if (val < 0) val = (int)StretchingValA;
                if (val > 255) val = (int)StretchingValB;
                LUT[i] = (byte)val;
            }
            var writeableBitmap = new WriteableBitmap(bitmapSource);

            int stride = (writeableBitmap.PixelWidth * writeableBitmap.Format.BitsPerPixel + 7) / 8;
            writeableBitmap.CopyPixels(pixels, stride, 0);
            //int index = (int)p.Y * stride + 4 * (int)p.X;
            for (int x = 0; x < writeableBitmap.PixelWidth; x++)
            {
                for (int y = 0; y < writeableBitmap.PixelHeight; y++)
                {
                    int rIndex = y * stride + 4 * x + 2;
                    int gIndex = y * stride + 4 * x + 1;
                    int bIndex = y * stride + 4 * x;
                    try
                    {
                        pixels[rIndex] = LUT[pixels[rIndex]];
                        pixels[gIndex] = LUT[pixels[gIndex]];
                        pixels[bIndex] = LUT[pixels[bIndex]];
                    }
                    catch (IndexOutOfRangeException) { }
                }
            }

            // zapisz do bitmapy
            Int32Rect rect = new Int32Rect(0, 0, writeableBitmap.PixelWidth, writeableBitmap.PixelHeight);
            writeableBitmap.WritePixels(rect, pixels, stride, 0);
            image.Source = writeableBitmap;
            bitmapSource = ConvertWriteableBitmapToBitmapImage(writeableBitmap);
        }

        private void EqualizeHistogram(object sender, RoutedEventArgs e)
        {
            var distribution = new double[256];
            var LUT = new byte[256];
            int sum = brightnessHistogramValues.Sum();
            for (int i = 0; i < 256; i++)
            {
                distribution[i] = (double)brightnessHistogramValues.Take(i + 1).Sum() / sum;

            }
            double d0 = distribution.First(val => val != 0);
            for (int i = 0; i < 256; i++)
            {
                var val = (distribution[i] - d0) / (1 - d0) * 255;
                if (val < 0) val = 0;
                if (val > 255) val = 255;
                LUT[i] = (byte)val;
            }

            var writeableBitmap = new WriteableBitmap(bitmapSource);

            int stride = (writeableBitmap.PixelWidth * writeableBitmap.Format.BitsPerPixel + 7) / 8;
            writeableBitmap.CopyPixels(pixels, stride, 0);
            //int index = (int)p.Y * stride + 4 * (int)p.X;
            for (int x = 0; x < writeableBitmap.PixelWidth; x++)
            {
                for (int y = 0; y < writeableBitmap.PixelHeight; y++)
                {
                    int rIndex = y * stride + 4 * x + 2;
                    int gIndex = y * stride + 4 * x + 1;
                    int bIndex = y * stride + 4 * x;
                    try
                    {
                        pixels[rIndex] = LUT[pixels[rIndex]];
                        pixels[gIndex] = LUT[pixels[gIndex]];
                        pixels[bIndex] = LUT[pixels[bIndex]];
                    }
                    catch (IndexOutOfRangeException) { }
                }
            }

            // zapisz do bitmapy
            Int32Rect rect = new Int32Rect(0, 0, writeableBitmap.PixelWidth, writeableBitmap.PixelHeight);
            writeableBitmap.WritePixels(rect, pixels, stride, 0);
            image.Source = writeableBitmap;
            bitmapSource = ConvertWriteableBitmapToBitmapImage(writeableBitmap);
        }
    }
}
